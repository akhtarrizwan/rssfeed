
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>index home page </title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">


.topnav ul {
	border-bottom: 1px solid #262626;
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #808080;
    max-height: 100px;
    position: fixed;
    top: 0;
    width: 100%;
    z-index: 10;
}

.topnav ul li {
	float: right;
}

.topnav ul li a {
	font-size: 18px;
    display: inline-block;
    color: #262626;
    text-align: center;
    padding: 23px 20px;
    text-decoration: none;
    transition: 0.9s;
}

.span-logo img {
	display: inline-block;
	vertical-align: top;
	height: 75px;
	min-height: 75px;
	width: 75px;
	min-width: 75px;
	float: left;
	padding: 0px;
}

.span-logo p {
	font-size: 26px;
	text-decoration: none;
	color: #808080;
	float: left;
	padding: 15px 0px;
}

.topnav ul li a:hover {background-color: #262626; color: #ffffff}

.topnav ul li.icon {display: none;}


@media screen and (max-width:680px) {
  .topnav.responsive ul {position: relative;}
  .topnav.responsive ul li.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive ul li {
    float: none;
    display: inline;
  }
  .topnav.responsive ul li a {
    display: block;
    text-align: left;
  }
}

.fancy-monk {
	font-size: 25px;
	color: #808080;
	text-align: right;
	height: 600px;
	min-height: 400px;
	background-color: #808080
}
.fancy-monk h1 {
	font-size: 40px;
	margin: 0;
	padding-top: 40px;
}
.signinup{
 width:100%;
 opacity:0.6;
}
.content
{
  width:150%;
  opacity:0.6;
  text-align: right;
}
.btn-danger{
    background:#808080;
    width:180px;
}
#particles-js {
    position: absolute;
    width: 100%;
    height: 200%;

    background: #262626;
}




    </style>
    <!--<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>-->
</head>
<body>

  <div id="particles-js"></div>
  <script type="text/javascript" src="particles.js"></script>
  <script type="text/javascript" src="app.js"></script>


		<div>
<div class="topnav">
		<ul>
			<li class="icon">
   				 <a href="javascript:void(0);" onclick="myFunction()">☰</a>
  			</li>
			<li><a href="#contact" title="">Contact</a></li>
			<li><a href="/forrestaurant/#" title="">About us</a></li>
			<li><a href="/forbusiness/#" title="">Give Feedback</a></li>
			<div>
				<a href="/home">
				<span class="span-logo">
				<img src="http://findicons.com/files/icons/1580/devine_icons_part_2/512/rss.png">
				</span>
				</a>
			</div>
		</ul>
	</div>



    <div class="fancy-monk">
<br>
<br>
<br>
<br>
      <div class="signinup">
             <div>Not a member yet?</div>
             <div>Sign up now</div>
             <div>
                <a href="login.php"> <input type="button" value="signin" class="btn btn-danger"></a>
                 <a href="signup.php"><input type="button" value="signup" class="btn btn-danger"></a>
             </div>
       </div>
      </div>
    </div>

	</div>
<script type="text/javascript">

</script>
</body>
</html>

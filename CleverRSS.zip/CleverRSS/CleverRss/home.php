<?php
    require_once 'library.php';
    if(chkLogin()){

        echo "Logged in!";
        $name = $_SESSION["uname"];
        echo "WELCOME TO RSS CLEVER $name";


    }
    else{
        header("Location: login.php");
    }

    if(isset($_POST['logout'])){

        $var = removeall();
        if($var){
            header("Location:login.php");
        }
        else{
            echo "Error!";
        }

    }
?>
<html>
<head>
  <meta charset="utf-8">

      <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet">
  <style type="text/css">

  </style>
  <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
  <script src="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<title>WELCOME TO RSS CLEVER</title>
</head>
    <body>
        <form method="post" action="">
            <input type="submit" name="logout" value="Logout!">
        </form>
        <div class='container'>
          <h1>Main Content Section</h1>
          <div class='navbar navbar-inverse'>
            <div class='navbar-inner nav-collapse' style="height: auto;">
              <ul class="nav">
                <li class="active"><a href="#">Home</a></li>
                <li><a href="#">Page One</a></li>
                <li><a href="#">Page Two</a></li>
              </ul>
            </div>
          </div>
          <div id='content' class='row-fluid'>
          <div class='span2 sidebar'>
              <h3>Left Sidebar</h3>
              <ul class="nav nav-tabs nav-stacked">
                <li><a href='#'>Another Link 1</a></li>
                <li><a href='#'>Another Link 2</a></li>
                <li><a href='#'>Another Link 3</a></li>
              </ul>
            </div>
            <div class='span8 main'>
              <h2>UPDATED FEEDS</h2>
              <p>i m too good</p>
              <p>yes i am</p>
            </div>
            <div class='span2 sidebar'>
              <h3>Right Sidebar</h3>
              <ul class="nav nav-tabs nav-stacked">
                <li><a href='#'>Another Link 1</a></li>
                <li><a href='#'>Another Link 2</a></li>
                <li><a href='#'>Another Link 3</a></li>
              </ul>
            </div>
          </div>
        </div>
    </body>
</html>

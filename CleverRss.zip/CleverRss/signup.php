<?php
    require_once 'library.php';
    if(chkLogin()){
        header("Location: home.php");
    }
?>
<html>
    <head>
          <meta charset="utf-8">
        <title>login</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
        <style type="text/css">
            .form-signup
    {

        max-width: 400px;
        padding: 15px;
        margin: 0 auto;
    }
    .form-signup .form-signup-heading,
    {
        margin-bottom: 10px;
    }

    .form-signup .form-control
    {


        position: relative;
        font-size: 16px;
        height: auto;
        padding: 10px;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }
    .form-signup .form-control:focus
    {
        z-index: 2;
    }

    .account-wall
    {
        margin-top: 20px;
        padding: 40px 0px 20px 0px;
        background-color: #f7f7f7;
        -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    }
    .signup-title
    {
        color: #555;
        font-size: 18px;
        font-weight: 400;
        display: block;
    }
    .profile-img
    {
        width: 96px;
        height: 96px;
        margin: 0 auto 10px;
        display: block;
        -moz-border-radius: 50%;
        -webkit-border-radius: 50%;
        border-radius: 50%;
    }


    #particles-js {
        position: absolute;
        width: 100%;
        height: 150%;

        background: #262626;
    }
    .content
    {
      color: #808080;
    }
        </style>
        <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    </head>

    <body>
      <div id="particles-js"></div>
      <script type="text/javascript" src="particles.js"></script>
      <script type="text/javascript" src="app.js"></script>

    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-4 col-md-offset-4">
                <h1 class="text-center signup-title">Sign up to rss</h1>
                <div class="account-wall">
                    <img class="profile-img" src="https://lh5.googleusercontent.com/-b0-k99FZlyE/AAAAAAAAAAI/AAAAAAAAAAA/eu7opA4byxI/photo.jpg?sz=120"
                        alt="">
        <form class="form-signup" action="signup_action.php" method="post">
          <div class="form-control">
            <label for="inputFname3">First Name</label>

              <input type="text" class="form-control" id="inputFname3" name="fname" placeholder="First Name" required>

          </div>
          <div class="form-control">
            <label for="inputLname3" >Last Name</label>

              <input type="text" class="form-control" id="inputLname3" name="lname" placeholder="Last Name" required>

          </div>
          <div class="form-control">
            <label for="inputEmail3" >Email</label>

              <input type="email" class="form-control" id="inputEmail3" name="email" placeholder="Email" required>

          </div>
          <div class="form-control">
            <label for="inputPassword3">Password</label>

              <input type="password" class="form-control" id="pass" name="pass" placeholder="Password" required>

          </div>
           <div class="form-control">
            <label for="inputCpassword3" >Confirm Password</label>

              <input type="password" class="form-control" id="cpass" name="cpass" onblur="chk()" placeholder="Confirm Password" required>
            <div id="error"></div>

          </div>
          <div class="form-control">

              <button type="submit" class="btn btn-default" name="reg">Sign Up</button>

          </div>
        </form>
        <script src="myscript.js" type="text/javascript"></script>
    </body>
</html>

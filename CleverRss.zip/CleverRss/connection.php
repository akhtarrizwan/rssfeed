<?php
require '../vendor/autoload.php';
    try{
    $m = new MongoDB\Client();
     //echo "Connection to database Successfull!";echo"<br />";
    // print_r($m);
    $db = $m->emp;
    //print_r($db);
    //echo "Databse loginreg selected";
    $collection = $db->details;
    //echo "Collection userdata Selected Successfully";
    }
    catch (Exception $e){
        die("Error. Couldn't connect to the server. Please Check");
    }
       session_start();
?>
